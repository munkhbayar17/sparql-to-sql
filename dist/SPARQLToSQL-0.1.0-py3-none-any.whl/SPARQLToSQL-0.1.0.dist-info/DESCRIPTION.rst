An SPARQL-to-SQL translator based on a semantics-preserving translation approach by Artem Chebotko


